
public class Main {

	public static void main(String[] args) {
		
		Queue q = new Queue();
		
		q.insert(8);
		q.insert(18);
		q.insert(47);
		
		q.display();
		
		q.insert(15);
		
		q.display();
		
		q.remove();
		q.display();
			

	}

}
