package LinkedList2;

public class Node {
	
	int data;
	Node next;
	
	public Node (int value) {
		
		this.data=value;
		this.next=null;
	}

	public Node () {}
	
}


