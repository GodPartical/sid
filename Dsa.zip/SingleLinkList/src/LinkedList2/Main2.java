package LinkedList2;
import java.util.*;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		linkList l1 = new linkList();
		Scanner sc = new Scanner(System.in);
		
		boolean exit = false;
		
		while(!exit) {
		  System.out.println(" 0 : exit ");
		  System.out.println("1 : addFirst");
		  System.out.println("2 : display ");
		  System.out.println(" 3 : add Last");
		  System.out.println(" 4 : delete First");
		  System.out.println(" 5 : delete Last");
		  switch(sc.nextInt()) {
		  case 0 : {
			  exit = true;
			  break;
		  }
		  case 1 : {
			  System.out.println("Enter the elemnt for add");
			  l1.AddFirst(sc.nextInt());
			  break;
		  }
		  case 2 : {
			  l1.display();
			  break;
		  }
		  case 3 : {
			  System.out.println("Enter the elemnt for add");
			  l1.addLast(sc.nextInt());
			  break;
		  }
		  case 4 : {
			  l1.delFirst();
			  break;
		  }
		  case 5 : {
			  l1.delLast();
			  break;

		  }
		  
		  }
		}
		
		

	}

}
