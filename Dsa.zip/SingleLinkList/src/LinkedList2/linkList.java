package LinkedList2;

public class linkList {

	Node head;
	int length;

	public linkList() {

		this.head = null;
		this.length = 0;
	}

	public void AddFirst(int data) {

		Node x = new Node(data);

		length++;

		if (head == null) {

			head = x;
			return;
		}

		x.next = head;
		head = x;

	}

	public void display() {
		if (head == null) {

			System.out.println("LIST is EMPTY");

			return;
		}

		Node temp = head;

		while (temp != null) {

			System.out.print(temp.data + " -> ");

			temp = temp.next;
		}
		System.out.println("Null");

	}

	public void addLast(int data) {

		length++;
		Node x = new Node(data);
		if (head == null) {

			head = x;
			return;

		}

		Node temp = head;
		while (temp.next != null) {

			temp = temp.next;

		}

		temp.next = x;

	}

	public void delFirst() {

		if (head == null) {

			System.out.println("Empty list");
			return;
		}
		length--;
		if (head.next == null) {
			head = null;
			return;
		}

		head = head.next;

	}

	public void delLast() {

		if (head == null) {

			System.out.println("Empty list");
			return;
		}
		length--;
		if (head.next == null) {
			head = null;
			return;
		}

		Node temp = head;
		while (temp.next.next != null) {

			temp = temp.next;
		}
		temp.next = null;
	}

	public void set(int data, int index) {

		if (head == null || length < index) {

			System.out.println("list out of bound");
			return;
		}

		Node temp = head;
		for (int a = 1; a < index; a++) {
			temp = temp.next;
		}

		temp.data = data;
	}

	public int get(int index) {

		if (head == null || length < index) {

			System.out.println("list out of bound");
			return -1;
		}
		Node temp = head;
		for (int a = 1; a < index; a++) {

			temp = temp.next;

		}
		return temp.data;
	}

	public void insertAt(int data, int index) {

		if (head == null || length < index) {

			System.out.println("list out of bound");
			return;
		}
		if (index == length + 1) {

			this.addLast(data);
			return;
		}
		length++;

		Node x = new Node(data);

		Node prev = head;
		Node curr = head.next;

		for (int a = 1; a < index - 1; a++) {

			prev = prev.next;
			curr = curr.next;

		}
		prev.next = x;
		x.next = curr;

	}

	public void sort() {

		// Node temp = head;
		for (int a = 0; a < length; a++) {

			for (int b = a + 1; b <= length; b++) {
				if (this.get(a) > this.get(b)) {

					int temp2 = this.get(a);
					this.set(this.get(b), a);
					this.set(temp2, b);
				}

			}
		}

	}

	public int search(int key) {
		// Node temp = head;

		for (int a = 0; a <= length; a++) {
			if (this.get(a) == key) {

				// System.out.println(a);
				return a;
			}

		}

		return -1;
	}

	public void delAt(int index) {

		if (head == null || length < index) {

			System.out.println("list out of bound");
			return;
		}
		if (index == length) {

			this.delLast();
			return;
		}
		length--;
		Node prev = head;
		Node curr = head.next;
		for (int a = 1; a < index - 1; a++) {

			prev = prev.next;
			curr = curr.next;
		}

		prev.next = curr.next;

	}

}
