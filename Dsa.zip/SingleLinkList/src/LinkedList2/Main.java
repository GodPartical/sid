package LinkedList2;

public class Main {

	public static void main(String[] args) {

		linkList l1 = new linkList();
		for (int a = 10; a >= 1; a--) {

			l1.AddFirst(a);
		}
		l1.display();
		l1.addLast(11);
		l1.display();
		l1.delFirst();
		l1.display();
		l1.delLast();
		l1.display();
		l1.set(100, 2);
		l1.display();
		System.out.println(l1.get(2));
		l1.insertAt(22, 7);
		l1.display();
		l1.sort();
		System.out.println(l1.length);
		l1.display();
		System.out.println(l1.search(5));
		System.out.println();
		System.out.println();
		l1.delAt(3);
		//l1.AddFirst(2);
		l1.display();

	}

}
