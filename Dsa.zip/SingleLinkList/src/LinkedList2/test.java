package LinkedList2;

import java.util.Arrays;

public class test {

	public static void main(String[] args) {

		int arr[]= {11,55,44,55,77,33,22,66};
		Arrays.sort(arr);
		for(int a : arr) {
			System.out.print(a + " ");
		}
		int count = 0;
		int x = 0;
		for(int a = 0; a<arr.length -1 ; a++) {
			for(int b = a+1; b< arr.length; b++) {
				if(arr[a] == arr[b]) {
					 x =a;
					count++;
				}
				
			}
		}
		System.out.println();
		System.out.println(count +" at position " + x );
	}

}
