package LinkedList01;

public class Main {

	public static void main(String[] args) {

		
		linkedList l1=new linkedList();
		l1.addFirst(55);
		l1.addFirst(4);
		l1.addFirst(33);
		l1.addFirst(2);
		l1.addFirst(1);
		l1.display();
		System.out.println("using AddLast fn");
		
		l1.addLast(6);
		l1.display();
	//	System.out.println(l1.get(5));
		System.out.println("Using InsertAt");
		l1.insertAt(55, 3);
		l1.display();
		System.out.println("Using set");
		l1.set(22, 2);
		l1.display();
		System.out.println("After Delete first");
		l1.delfirst();
		l1.display();
		
		System.out.println("After Delete Last");
		l1.dellast();
		l1.display();
	//	System.out.println(l1.length);
	}

}
