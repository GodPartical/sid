 package LinkedList01;

public class linkedList {

	Node head;
	int length;

	public linkedList() {
		this.head = null;
		this.length = 0;
	}

	public void addFirst(int a) {
		length++;
		Node x = new Node(a);

		if (head == null) {
			head = x;
			return;

		}

		x.next = head;
		head = x;

	}

	public void display() {
		if (head == null) {

			System.out.println("List is empty");
			return;
		}

		Node x = head;
		while (x != null) {

			System.out.print(x.data + " -> ");
			x = x.next;
		}
		System.out.println("null");

	}

	public void addLast(int data) {
		Node x = new Node(data);
		length++;
		if (head == null) {

			head = x;
			return;

		}
		Node temp = head;
		while (temp.next != null) {

			temp = temp.next;
		}

		temp.next = x;
	}

	public int get(int index) {

		if (index > length || index < 0) {

			System.out.println("Invalid Index");
			return -1;
		}

		Node temp = head;
		for (int a = 1; a < index; a++) {

			temp = temp.next;
		}

		return temp.data;
	}

	public void set(int data, int index) {

		if (index > length || index < 0) {

			System.out.println("invalid index");
			return;
		}

		Node temp = head;
		for (int a = 1; a < index; a++) {

			temp = temp.next;

		}
		temp.data = data;

	}

	public void insertAt(int data, int index) {

		if (index > length || index < 0) {

			System.out.println("Invalid Index");
			return;
		}
		length++;
		Node x = new Node(data);
		Node prev = head;
		Node curr = head.next;
		for (int a = 1; a < index - 1; a++) {

			prev = prev.next;
			curr = curr.next;
		}
		prev.next = x;
		x.next = curr;
	}

	public void delfirst() {

		if (head == null) {

			return;
		}

		length--;

		if (head.next == null) {

			head = null;

		}

		head = head.next;

	}

	public void dellast() {

		if (head == null) {

			return;
		}

		length--;

		if (head.next == null) {

			head = null;

		}
		
		Node temp=head;
		while(temp.next.next!=null) {
			
			temp = temp.next;
			
		}
		
		temp.next=null;

	}
}
