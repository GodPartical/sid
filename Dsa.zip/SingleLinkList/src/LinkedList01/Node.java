package LinkedList01;

public class Node {

	
	int data;
	Node next;
	
	Node(int value){
		this.data = value;
		this.next=null;
		
	}
	
	Node(){}
	
}
