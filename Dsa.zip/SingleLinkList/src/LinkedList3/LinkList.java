package LinkedList3;

import LinkedList2.linkList;

public class LinkList {

	Node head;
	int length;
	
	
	public LinkList() {
		
		this.head=null;
		this.length=0;
		
	}
	public void AddFirst(int data) {
		
		Node x = new Node(data);
		
		length++;
		if(head==null) {
			
			head =x ;
			return;
			
		}
		
		x.next=head;
		head=x;
	}
	
	public void display() {
		
		if (head == null) {
			
			System.out.println("empty");
			return;
		}
		
		Node temp=head;
		while(temp!=null) {
			
			System.out.println(temp.data);
			temp=temp.next;
		}
		
	}
	
	
	
	
	
	
	
}
