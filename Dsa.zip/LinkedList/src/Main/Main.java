package Main;

public class Main {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		
		for(int a = 5; a>= 1; a--) {
			list.addFirst(a);
		}
		list.display();
		list.addlast(6);
		list.display();
		list.addAtPosition(20,2);
		list.display();
		
		System.out.println("Element is at = "+list.search(20));
	}	

}
