package Main;

public class LinkedList {

	
	Node head;
	int length;
	public LinkedList() {

	this.head=null;
	this.length=0;
	}

public void addFirst(int data) {
	
	
	length++;
	Node x=new Node(data);
	if (head==null) {
		
		head = x;
		return;
	}
			x.next=head;	
			head=x;
			
			
}

public void display() {
	Node temp = head;
	
	while(temp != null) {
		System.out.print(temp.data + " ->");
		temp = temp.next;
	}
	System.out.println("Null");
}


public void addlast(int data) {
	
	
	length++;
	Node x = new Node (data);
	if(head==null) {
		head=x;
		return;
		
	}
	Node temp = head;
	while(temp.next!=null) {
		temp=temp.next;
		
	}
	
	temp.next=x;
}

public void addAtPosition(int data , int index) {
	
	if(!(index +1<length)){
		System.out.println("ArrayOutOfBound");
	return;
	}
	
	length++;
	Node x = new Node(data);
	Node prev = head;
	Node curr= head.next;
	for(int a=0; a<index-1;a++){
		
		prev =prev.next;
		curr = curr.next;
		
		
	}
		prev.next=x;
		x.next=curr;

}

public int search(int key) {
	
	 Node temp = head;
	 for(int a = 0; a<=length; a++) {
		 
		 if (temp.data==key) {
			 return a;
			 
		 }
		 temp = temp.next;
	 }
	
	
	return -1;
	
	
	
}

}