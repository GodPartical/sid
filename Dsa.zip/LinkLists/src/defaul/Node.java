package defaul;


public class Node {
	int data;
	Node next;
	
	Node (int a){
		this.data =a;
		this.next = null;
	}
	
	Node (){
		
	}

}

