package Stack;

public class stack {
	int arr[] = new int[1000];
	int counter = -1;
	
	public boolean isEmpty() {
		return counter == -1;
	}
	
	public void push(int data) {
		arr[++counter] = data;
		return;
	}
	
	public int pop() {
		if(this.isEmpty()) {
			return -1;
		}
		return arr[counter--];
	}
	
	public int peek() {
		if(this.isEmpty()) {
			return -1;
		}
		return arr[counter];
	}

}
