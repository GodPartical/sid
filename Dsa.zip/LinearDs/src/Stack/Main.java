package Stack;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		stack s1 = new stack();
		for(int a = 1; a<= 10; a++) {
			s1.push(a);
		}
		while(!s1.isEmpty())
		{
			System.out.println(s1.pop());
		}
		//Stack<Integer>s2 = new Stack<Integer>();
		
	}
}
