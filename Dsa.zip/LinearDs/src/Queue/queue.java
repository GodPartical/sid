package Queue;

public class queue {
	int arr[] = new int[1000];
	int rear = 0;
	int front = 0;
	int size = -1;
	
	public boolean isEmpty() {
		return  size == -1;
	}
	public void add(int a) {
	
		arr[rear++] = a;
		size++;
	}
	public int get() {
		if(isEmpty()) {
			return -1;
		}
		size--;
		return arr[front++];
	}
	public int first() {
		if(isEmpty()) {
			return -1;
		}
		return arr[front];
	}
	
   public int  search(int key) {
	   for(int a = 0; a<size; a++) {
		   if(arr[a] == key) {
			   System.out.println("Found");
			   return a;
			   
		   }
	   }
	   return -1;
   }
   public int getValue(int index) {
	   if(isEmpty() || size < index) {
		   return -1;
	   }
	   return arr[index];
	   
   }
	

}
