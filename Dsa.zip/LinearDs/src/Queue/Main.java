package Queue;

public class Main {

	public static void main(String[] args) {
		queue q1 = new queue();
		for(int a = 11; a<= 20; a++) {
			q1.add(a);
		}

//		System.out.println();
//		while(!q1.isEmpty()) {
//			System.out.println(q1.get());
//		}
		System.out.println(q1.search(100));
		System.out.println(q1.getValue(8));
	}

}
