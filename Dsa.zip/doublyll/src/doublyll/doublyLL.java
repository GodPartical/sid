package doublyll;

public class doublyLL {
	
	Node head;
	int size;
	
	doublyLL(){
		this.head = null;
		this.size = 0;
	}
	
	
	public void addFirst(int data) {
		Node x = new Node(data);
		size++;
		if(head == null) {
			head = x;
			x.prev=x.next=null;
			return;
		}
		head.prev = x;
		x.next= head;
		head = x;
	}
	
	public void displayFromFirst() {
		if(head == null) {
			System.out.println("Empty");
			return;
		}
		Node temp = head;
		while(temp != null) {
			System.out.print(temp.data +" -> ");
			temp = temp.next;
		}
		System.out.println("Null");
	}
	
	
	
public void addLast(int data) {
	Node x = new Node(data);
	size++;
	if (head == null) {
		head = x;
		return;
	}
	
	Node temp = head;
	while(temp.next != null) {
		temp = temp.next;
	}
	temp.next = x;
	x.prev = temp.next;
	
}

public void deleteFirst() {
	if(head == null) {
		return;
	}
	size--;
	if(head.next == null) {
		head = null;
		return;
	}
	head = head.next;
	head.next.prev = null;
	
}

public void deleteLast() {
	if(head == null) {
		return;
	}
	size--;
	if(head.next == null) {
		head = null;
		return;
	}
	Node temp = head;
	while(temp.next.next != null) {
		temp = temp.next;
	}
	temp.next = null;
	
	
}
	

}
