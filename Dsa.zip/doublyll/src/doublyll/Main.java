package doublyll;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		doublyLL list = new doublyLL();
		
		list.addFirst(50);
		list.addFirst(40);
		list.addFirst(30);
		list.addLast(60);
		list.deleteFirst();
		list.deleteLast();
		list.displayFromFirst();
		
	//System.out.println("The mid is : "+ list.findMid());
	

	}

}
